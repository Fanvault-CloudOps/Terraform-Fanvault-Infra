const { SNSClient, PublishCommand } = require("@aws-sdk/client-sns");
const sns = new SNSClient({});

exports.handler = async (event) => {
  console.log("Received EventBridge event:", JSON.stringify(event, null, 2));

  const detail = event.detail || {};
  const productId = detail.productId || "unknown";
  const productName = detail.name || "unknown";
  const sku = detail.sku || "unknown";
  const stock = detail.stock ?? "unknown";
  const correlationId = detail.correlationId || event.id || "system";

  console.warn(`[ALERT] INVENTORY MONITOR WARNING: Product stock is critically low!`);
  console.warn(`[ALERT] Product Details:
    - ID: ${productId}
    - Name: ${productName}
    - SKU: ${sku}
    - Current Stock: ${stock}
    - Alert Timestamp: ${detail.timestamp || new Date().toISOString()}
  `);

  const topicArn = process.env.SNS_TOPIC_ARN;
  if (!topicArn) {
    console.error("SNS_TOPIC_ARN environment variable not configured.");
    return { status: "skipped", reason: "no_topic_arn" };
  }

  const payload = {
    service: "fanvault-commerce-service",
    eventType: "LowInventoryAlert",
    resource: `Product:${productId}`,
    timestamp: detail.timestamp || new Date().toISOString(),
    severity: "WARNING",
    correlationId,
    details: {
      productId,
      productName,
      sku,
      currentStock: stock
    }
  };

  try {
    const response = await sns.send(new PublishCommand({
      TopicArn: topicArn,
      Message: JSON.stringify(payload, null, 2),
      Subject: `Low Inventory Alert: ${productName} (${sku})`
    }));
    console.log("Alert published to SNS successfully. MessageId:", response.MessageId);
    return { status: "success", alertSent: true, messageId: response.MessageId };
  } catch (err) {
    console.error("Failed to publish alert to SNS:", err.message);
    throw err;
  }
};
