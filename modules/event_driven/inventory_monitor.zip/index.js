exports.handler = async (event) => {
  console.log("Received EventBridge event:", JSON.stringify(event, null, 2));

  const detail = event.detail || {};
  const productId = detail.productId || "unknown";
  const productName = detail.name || "unknown";
  const sku = detail.sku || "unknown";
  const stock = detail.stock ?? "unknown";

  console.warn(`[ALERT] INVENTORY MONITOR WARNING: Product stock is critically low!`);
  console.warn(`[ALERT] Product Details:
    - ID: ${productId}
    - Name: ${productName}
    - SKU: ${sku}
    - Current Stock: ${stock}
    - Alert Timestamp: ${detail.timestamp || new Date().toISOString()}
  `);
  
  return { status: "success", alertSent: true };
};
