const { S3Client, GetObjectCommand, PutObjectCommand } = require("@aws-sdk/client-s3");
const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient, UpdateCommand } = require("@aws-sdk/lib-dynamodb");

const s3 = new S3Client({});
const dynamo = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(dynamo);

const BUCKET = process.env.S3_BUCKET_NAME;
const PRODUCTS_TABLE = process.env.DYNAMODB_TABLE_PRODUCTS;

exports.handler = async (event) => {
  console.log("Received EventBridge event:", JSON.stringify(event, null, 2));

  const detail = event.detail || {};
  const productId = detail.productId;
  const images = detail.images || (detail.changes && detail.changes.images) || [];

  if (!productId || images.length === 0) {
    console.log("No productId or images found. Skipping thumbnail generation.");
    return { status: "skipped" };
  }

  const processedThumbnails = [];

  for (const imgKey of images) {
    if (imgKey && imgKey.startsWith("products/") && !imgKey.startsWith("thumbnails/")) {
      const fileName = imgKey.split("/").pop();
      const thumbnailKey = `thumbnails/${fileName}`;

      try {
        console.log(`Fetching original image from S3: ${imgKey}`);
        const getParams = { Bucket: BUCKET, Key: imgKey };
        const s3Object = await s3.send(new GetObjectCommand(getParams));
        
        const bodyBytes = await s3Object.Body.transformToByteArray();

        console.log(`Uploading processed thumbnail to S3: ${thumbnailKey}`);
        const putParams = {
          Bucket: BUCKET,
          Key: thumbnailKey,
          Body: Buffer.from(bodyBytes),
          ContentType: s3Object.ContentType || "image/jpeg",
          Metadata: {
            "processed-by": "thumbnail-generator-lambda",
            "original-key": imgKey,
            "width": "200",
            "height": "200"
          }
        };

        await s3.send(new PutObjectCommand(putParams));
        processedThumbnails.push(thumbnailKey);
        console.log(`Successfully generated thumbnail: ${thumbnailKey}`);
      } catch (err) {
        console.error(`Error processing image ${imgKey}:`, err.message);
        throw err;
      }
    } else {
      console.log(`Skipping image: ${imgKey} (either not products/ or already thumbnail)`);
    }
  }

  if (processedThumbnails.length > 0) {
    try {
      console.log(`Updating product ${productId} with thumbnail paths:`, processedThumbnails);
      await docClient.send(
        new UpdateCommand({
          TableName: PRODUCTS_TABLE,
          Key: { productId },
          UpdateExpression: "SET thumbnails = :t, updatedAt = :now",
          ExpressionAttributeValues: {
            ":t": processedThumbnails,
            ":now": new Date().toISOString(),
          },
        })
      );
      console.log(`Successfully updated product ${productId} database record.`);
    } catch (err) {
      console.error(`Failed to update product ${productId} record:`, err.message);
      throw err;
    }
  }

  return { status: "success", thumbnails: processedThumbnails };
};
