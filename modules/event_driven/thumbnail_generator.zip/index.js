const { S3Client, GetObjectCommand, PutObjectCommand } = require("@aws-sdk/client-s3");
const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient, UpdateCommand } = require("@aws-sdk/lib-dynamodb");
const { SNSClient, PublishCommand } = require("@aws-sdk/client-sns");

const s3 = new S3Client({});
const dynamo = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(dynamo);
const sns = new SNSClient({});

const BUCKET = process.env.S3_BUCKET_NAME;
const PRODUCTS_TABLE = process.env.DYNAMODB_TABLE_PRODUCTS;
const SNS_TOPIC_ARN = process.env.SNS_TOPIC_ARN;

async function publishFailure(productId, errorMsg, originalKey, correlationId) {
  if (!SNS_TOPIC_ARN) {
    console.error("SNS_TOPIC_ARN not configured.");
    return;
  }
  const payload = {
    service: "thumbnail-generator-lambda",
    eventType: "ProductUploadFailure",
    resource: `Product:${productId || "unknown"}`,
    timestamp: new Date().toISOString(),
    severity: "ERROR",
    correlationId,
    details: {
      productId,
      imageKey: originalKey,
      errorMessage: errorMsg
    }
  };
  try {
    await sns.send(new PublishCommand({
      TopicArn: SNS_TOPIC_ARN,
      Message: JSON.stringify(payload, null, 2),
      Subject: `Product Upload Failure Alert: Product ${productId || "unknown"}`
    }));
    console.log("Upload failure alert sent to SNS.");
  } catch (err) {
    console.error("Failed to send upload failure alert to SNS:", err.message);
  }
}

exports.handler = async (event) => {
  console.log("Received EventBridge event:", JSON.stringify(event, null, 2));

  const detail = event.detail || {};
  const productId = detail.productId;
  const images = detail.images || (detail.changes && detail.changes.images) || [];
  const correlationId = detail.correlationId || event.id || "system";

  if (!productId || images.length === 0) {
    console.log("No productId or images found. Skipping thumbnail generation.");
    return { status: "skipped" };
  }

  const processedThumbnails = [];

  for (const imgKey of images) {
    if (imgKey && imgKey.startsWith("products/") && !imgKey.startsWith("thumbnails/")) {
      const fileName = imgKey.split("/").pop();
      const thumbnailKey = `thumbnails/${fileName}`;

      try {
        console.log(`Fetching original image from S3: ${imgKey}`);
        const getParams = { Bucket: BUCKET, Key: imgKey };
        const s3Object = await s3.send(new GetObjectCommand(getParams));
        
        const bodyBytes = await s3Object.Body.transformToByteArray();

        console.log(`Uploading processed thumbnail to S3: ${thumbnailKey}`);
        const putParams = {
          Bucket: BUCKET,
          Key: thumbnailKey,
          Body: Buffer.from(bodyBytes),
          ContentType: s3Object.ContentType || "image/jpeg",
          Metadata: {
            "processed-by": "thumbnail-generator-lambda",
            "original-key": imgKey,
            "width": "200",
            "height": "200"
          }
        };

        await s3.send(new PutObjectCommand(putParams));
        processedThumbnails.push(thumbnailKey);
        console.log(`Successfully generated thumbnail: ${thumbnailKey}`);
      } catch (err) {
        console.error(`Error processing image ${imgKey}:`, err.message);
        await publishFailure(productId, err.message, imgKey, correlationId);
        throw err;
      }
    } else {
      console.log(`Skipping image: ${imgKey} (either not products/ or already thumbnail)`);
    }
  }

  if (processedThumbnails.length > 0) {
    try {
      console.log(`Updating product ${productId} with thumbnail paths:`, processedThumbnails);
      await docClient.send(
        new UpdateCommand({
          TableName: PRODUCTS_TABLE,
          Key: { productId },
          UpdateExpression: "SET thumbnails = :t, updatedAt = :now",
          ExpressionAttributeValues: {
            ":t": processedThumbnails,
            ":now": new Date().toISOString(),
          },
        })
      );
      console.log(`Successfully updated product ${productId} database record.`);
    } catch (err) {
      console.error(`Failed to update product ${productId} record:`, err.message);
      await publishFailure(productId, err.message, "db_update_failure", correlationId);
      throw err;
    }
  }

  return { status: "success", thumbnails: processedThumbnails };
};
