const { S3Client, GetObjectCommand } = require("@aws-sdk/client-s3");
const s3 = new S3Client({});

exports.handler = async (event) => {
    try {
        const command = new GetObjectCommand({
            Bucket: "fanvault-architecture-20260609040014475600000001",
            Key: "architecture.png"
        });
        const response = await s3.send(command);
        const body = await response.Body.transformToByteArray();
        const base64String = Buffer.from(body).toString("base64");

        return {
            statusCode: 200,
            statusDescription: "200 OK",
            isBase64Encoded: true,
            headers: {
                "Content-Type": "image/png",
                "Cache-Control": "public, max-age=86400"
            },
            body: base64String
        };
    } catch (err) {
        return {
            statusCode: 500,
            headers: { "Content-Type": "text/plain" },
            body: "Internal Server Error: " + err.message
        };
    }
};
